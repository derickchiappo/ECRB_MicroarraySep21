#' The IRIS cell subset signatures
#'
#' A list of gene sets representing cell subsets.
#'
#' @format A list with 8 unique signatures
"irisSignatures"