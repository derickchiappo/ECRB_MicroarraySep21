load(spec)


##read in your expression matrix here. 
##For this to work with the gene signatures I have, the row names need to be gene symbols
exprsVals = read.csv("Test matrix.csv", row.names=1,header=F)

##read in a query signature. The method is only meant to work with gene sets above 15 genes
##if you want, you can read in multiple query signatures and run them all at once in SPEC
querySig = unique(as.vector(read.table("PalmerSigs/B.txt")[,1]))

##calculate the enrichment of the cell subsets. 
##The default uses the cell signatures from Abbas et al. and Palmer et al.
subsetEnrichment = cellSubsetEnrich(exprsVals)
 
##calculate the correlation matrix for the query signatures of interest
SPEC(exprsVals, "querySig", subsetEnrichment)